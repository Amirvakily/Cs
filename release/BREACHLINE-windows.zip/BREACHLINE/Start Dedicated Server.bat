@echo off
title BREACHLINE Dedicated Server
cd /d "%~dp0"
echo Starting BREACHLINE dedicated server... (settings: server.cfg)
BREACHLINE.console.exe --headless -- --server
pause

@echo off
title BREACHLINE Master Server
cd /d "%~dp0"
echo Starting BREACHLINE master server on UDP 27900...
BREACHLINE.console.exe --headless -- --master
pause
